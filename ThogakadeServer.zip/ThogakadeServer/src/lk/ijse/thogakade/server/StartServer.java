
package lk.ijse.thogakade.server;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import lk.ijse.thogakade.service.impl.ServiceFactoryImpl;

public class StartServer {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.createRegistry(500);
            System.out.println("Server Starting..");
            registry.rebind("ThogakadeServer", ServiceFactoryImpl.getInstance());
        } catch (RemoteException ex) {
            Logger.getLogger(StartServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
