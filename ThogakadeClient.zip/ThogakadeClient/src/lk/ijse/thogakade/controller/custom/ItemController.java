
package lk.ijse.thogakade.controller.custom;

import java.util.ArrayList;
import lk.ijse.thogakade.controller.SuperController;
import lk.ijse.thogakade.dto.ItemDTO;

public interface ItemController extends SuperController<ItemDTO>{
    
}
