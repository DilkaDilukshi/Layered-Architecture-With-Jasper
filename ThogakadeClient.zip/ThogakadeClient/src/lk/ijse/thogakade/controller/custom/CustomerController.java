
package lk.ijse.thogakade.controller.custom;

import lk.ijse.thogakade.controller.SuperController;
import lk.ijse.thogakade.dto.CustomerDTO;

public interface CustomerController extends SuperController<CustomerDTO>{
    
}
