
package lk.ijse.thogakade.service;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.SQLException;
import lk.ijse.thogakade.observers.Subject;


public interface ServiceFactory extends Remote{
    
    public enum ServiceTypes{
        CUSTOMER, ORDER,ITEM;
    }
    
    public SuperService getService(ServiceTypes serviceType) throws RemoteException;
    
}
