
package lk.ijse.thogakade.service.custom;

import java.rmi.Remote;
import lk.ijse.thogakade.dto.ItemDTO;
import lk.ijse.thogakade.service.SuperService;


public interface ItemService extends SuperService<ItemDTO>{
    
    
}
