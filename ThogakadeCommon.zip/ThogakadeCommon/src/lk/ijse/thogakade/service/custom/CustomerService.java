
package lk.ijse.thogakade.service.custom;

import lk.ijse.thogakade.dto.CustomerDTO;
import lk.ijse.thogakade.observers.Subject;
import lk.ijse.thogakade.service.SuperService;

public interface CustomerService extends SuperService<CustomerDTO>{
    
    
}
